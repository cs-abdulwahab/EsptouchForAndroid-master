[[English]](log-en.md)

# Update Log

## v1.1.1
EspTouch v0.3.7.2
- 优化权限检查和状态提示

## v1.1.0
EspTouch v0.3.7.2
- 使用AndroidX库
- 修改应用主题
- 增加签名文件

## v1.0.0
EspTouch v0.3.7.1
- 增加中文
- 在Android9.0下若获取不到Wi-Fi信息，检查GPS状态
- 隐藏EsptouchTask的aes构造函数, 设备暂不支持
