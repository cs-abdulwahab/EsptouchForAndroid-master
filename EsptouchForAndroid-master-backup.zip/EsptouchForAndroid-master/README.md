# EspTouch for Android
This APP is used to configure ESP devices to connect target AP, the devices need run [smart config](https://github.com/espressif/esp-idf/tree/master/examples/wifi/smart_config).

## Licence
- See [Licence](ESPRESSIF_MIT_LICENSE)

## Version Log
- See [Log](log/log-en.md)

## Modules
- EspTouch: [esptouch](esptouch)

## Releases
- See [releases](https://github.com/EspressifApp/EsptouchForAndroid/releases/latest), contain APK and aar
- For programmer, if you don't want use [esptouch](esptouch) module, download the aar into your own project.
